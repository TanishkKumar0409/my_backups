import User from "../Modals/User.js";
import bcryptjs from "bcryptjs";

const addUser = async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    var salt = bcryptjs.genSaltSync(10);
    var hash = bcryptjs.hashSync(password, salt);

    const existingEmail = await User.findOne({ email });
    if (existingEmail) {
      return res.json({ message: "Email is Already Exist" });
    }

    const existingPhone = await User.findOne({ phone });
    if (existingPhone) {
      return res.json({ message: "Phone is Already Exist" });
    }

    const newUser = new User({
      name,
      email,
      phone,
      password: hash,
    });

    const SavedUser = await newUser.save();

    return res.json({
      message: "User Saved Successfully",
      SavedUser,
    });
  } catch (error) {
    return res.json({ error: error.message });
  }
};

export default addUser;
