import React from "react";

export default function Home() {
  return (
    <>
      <section className="container vh-100 d-flex align-items-center justify-content-center">
        <div className="row">
            <div className="col">
                <h1>HOME</h1>
            </div>
        </div>
      </section>
    </>
  );
}
