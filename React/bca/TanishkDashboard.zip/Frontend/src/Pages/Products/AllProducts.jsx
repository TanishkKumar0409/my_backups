import React from "react";

export default function AllProducts() {
  return (
    <>
      <div className="container-fluid pt-4 px-4">
        <div className="bg-sec-custom rounded p-4 d-flex">
          <h1>All Products</h1>
        </div>
      </div>
    </>
  );
}
